﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Club_and_Societies_Management_System
{
    public partial class viewclubs : Form
    {
        MySqlConnectionStringBuilder builder;
        public viewclubs()
        {
            InitializeComponent();
            builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                UserID = "root",
                Password = "",
                Database = "club_management_system",

            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(builder.ConnectionString);
            con.Open();
            string query = "SELECT * FROM `club`";
            MySqlCommand cmd = new MySqlCommand(query, con);
            MessageBox.Show("Data is Shown");
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(builder.ConnectionString);
            con.Open();
            string query = "UPDATE `club` SET `club_name`= 'Royal' ,`department`= 'BBA' ,`club_slogan`= 'our rules our fun' WHERE `club_id`= 2";
            MySqlCommand cmd = new MySqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data is updated");
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(builder.ConnectionString);
            con.Open();
            string query = "DELETE FROM `club` WHERE `club_id`= 22";
            MySqlCommand cmd = new MySqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data is deleted");
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
