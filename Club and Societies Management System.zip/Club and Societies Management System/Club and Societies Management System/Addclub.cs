﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Club_and_Societies_Management_System
{
    public partial class Addclub : Form
    {
        MySqlConnectionStringBuilder builder;
        public Addclub()
        {
            
            InitializeComponent();
            builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                UserID = "root",
                Password = "",
                Database = "club_management_system",

            };

        }

        private void Addclub_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(builder.ConnectionString);                                                                   
            con.Open(); 
            string query = "INSERT INTO `club`(`club_id`, `club_name`, `department`, `club_slogan`) VALUES ('"+ textBox4.Text+ "', '"+textBox1.Text+ "', '" + textBox2.Text + "', '" + textBox3.Text + "' )";
            MySqlCommand cmd = new MySqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data is Saved");
            con.Close();

        }
    }
}
