﻿
namespace Club_and_Societies_Management_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cLUBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addClubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eVENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addClubToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eVENTSToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addEventToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewEventsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewClubsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nEWSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.RosyBrown;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cLUBToolStripMenuItem,
            this.eVENTSToolStripMenuItem,
            this.eVENTSToolStripMenuItem1,
            this.nEWSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 38);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cLUBToolStripMenuItem
            // 
            this.cLUBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addClubToolStripMenuItem});
            this.cLUBToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cLUBToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.cLUBToolStripMenuItem.Name = "cLUBToolStripMenuItem";
            this.cLUBToolStripMenuItem.Size = new System.Drawing.Size(88, 34);
            this.cLUBToolStripMenuItem.Text = "HOME";
            // 
            // addClubToolStripMenuItem
            // 
            this.addClubToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.addClubToolStripMenuItem.Name = "addClubToolStripMenuItem";
            this.addClubToolStripMenuItem.Size = new System.Drawing.Size(180, 34);
            this.addClubToolStripMenuItem.Text = "Welcome";
            this.addClubToolStripMenuItem.Click += new System.EventHandler(this.addClubToolStripMenuItem_Click);
            // 
            // eVENTSToolStripMenuItem
            // 
            this.eVENTSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addClubToolStripMenuItem1,
            this.viewClubsToolStripMenuItem});
            this.eVENTSToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eVENTSToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.eVENTSToolStripMenuItem.Name = "eVENTSToolStripMenuItem";
            this.eVENTSToolStripMenuItem.Size = new System.Drawing.Size(89, 34);
            this.eVENTSToolStripMenuItem.Text = "CLUBS";
            this.eVENTSToolStripMenuItem.Click += new System.EventHandler(this.eVENTSToolStripMenuItem_Click);
            // 
            // addClubToolStripMenuItem1
            // 
            this.addClubToolStripMenuItem1.ForeColor = System.Drawing.Color.Indigo;
            this.addClubToolStripMenuItem1.Name = "addClubToolStripMenuItem1";
            this.addClubToolStripMenuItem1.Size = new System.Drawing.Size(194, 34);
            this.addClubToolStripMenuItem1.Text = "Add Club";
            this.addClubToolStripMenuItem1.Click += new System.EventHandler(this.addClubToolStripMenuItem1_Click);
            // 
            // eVENTSToolStripMenuItem1
            // 
            this.eVENTSToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEventToolStripMenuItem,
            this.viewEventsToolStripMenuItem});
            this.eVENTSToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eVENTSToolStripMenuItem1.ForeColor = System.Drawing.Color.Indigo;
            this.eVENTSToolStripMenuItem1.Name = "eVENTSToolStripMenuItem1";
            this.eVENTSToolStripMenuItem1.Size = new System.Drawing.Size(102, 34);
            this.eVENTSToolStripMenuItem1.Text = "EVENTS";
            this.eVENTSToolStripMenuItem1.Click += new System.EventHandler(this.eVENTSToolStripMenuItem1_Click);
            // 
            // addEventToolStripMenuItem
            // 
            this.addEventToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.addEventToolStripMenuItem.Name = "addEventToolStripMenuItem";
            this.addEventToolStripMenuItem.Size = new System.Drawing.Size(203, 34);
            this.addEventToolStripMenuItem.Text = "Add Event";
            this.addEventToolStripMenuItem.Click += new System.EventHandler(this.addEventToolStripMenuItem_Click);
            // 
            // viewEventsToolStripMenuItem
            // 
            this.viewEventsToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.viewEventsToolStripMenuItem.Name = "viewEventsToolStripMenuItem";
            this.viewEventsToolStripMenuItem.Size = new System.Drawing.Size(203, 34);
            this.viewEventsToolStripMenuItem.Text = "View Events";
            this.viewEventsToolStripMenuItem.Click += new System.EventHandler(this.viewEventsToolStripMenuItem_Click);
            // 
            // viewClubsToolStripMenuItem
            // 
            this.viewClubsToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.viewClubsToolStripMenuItem.Name = "viewClubsToolStripMenuItem";
            this.viewClubsToolStripMenuItem.Size = new System.Drawing.Size(194, 34);
            this.viewClubsToolStripMenuItem.Text = "View Clubs";
            this.viewClubsToolStripMenuItem.Click += new System.EventHandler(this.viewClubsToolStripMenuItem_Click);
            // 
            // nEWSToolStripMenuItem
            // 
            this.nEWSToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nEWSToolStripMenuItem.ForeColor = System.Drawing.Color.Indigo;
            this.nEWSToolStripMenuItem.Name = "nEWSToolStripMenuItem";
            this.nEWSToolStripMenuItem.Size = new System.Drawing.Size(86, 34);
            this.nEWSToolStripMenuItem.Text = "NEWS";
            this.nEWSToolStripMenuItem.Click += new System.EventHandler(this.nEWSToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cLUBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eVENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addClubToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addClubToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem eVENTSToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addEventToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewClubsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewEventsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nEWSToolStripMenuItem;
    }
}

