﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Club_and_Societies_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addClubToolStripMenuItem_Click(object sender, EventArgs e)
        {
            welcome w = new welcome();
            w.Show();
            w.MdiParent = this;

        }

        private void addClubToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Addclub c1 = new Addclub();
            c1.Show();
            c1.MdiParent = this;

        }

        private void eVENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void eVENTSToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void addEventToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addevent a = new addevent();
            a.Show();
            a.MdiParent = this;
        }

        private void viewEventsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewevents a = new viewevents();
            a.Show();
            a.MdiParent = this;
        }

        private void viewClubsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewclubs a = new viewclubs();
            a.Show();
            a.MdiParent = this;
        }

        private void nEWSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            news a = new news();
            a.Show();
            a.MdiParent = this;
        }
    }
}
