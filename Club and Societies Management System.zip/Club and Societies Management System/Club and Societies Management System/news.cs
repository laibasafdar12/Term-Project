﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Club_and_Societies_Management_System
{
    public partial class news : Form
    {

        MySqlConnectionStringBuilder builder;
        public news()
        {
            InitializeComponent();
            builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                UserID = "root",
                Password = "",
                Database = "club_management_system",

            };
        }

        private void label2_Click(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(builder.ConnectionString);
            con.Open();
            string query = "SELECT * FROM `upcoming_event`";
            MySqlCommand cmd = new MySqlCommand(query, con);
            MessageBox.Show("Data is Shown");
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(builder.ConnectionString);
            con.Open();
            string query = "SELECT * FROM `past_events`";
            MySqlCommand cmd = new MySqlCommand(query, con);
            MessageBox.Show("Data is Shown");
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            con.Close();
        }
    }
}
